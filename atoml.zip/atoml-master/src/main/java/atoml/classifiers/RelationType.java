package atoml.classifiers;

public enum RelationType {
	SCORE_EXACT, CLASS_EXACT, CLASS_STAT, SCORE_STAT, CLUST_EXACT, CLUST_STAT;
}
